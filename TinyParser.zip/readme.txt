this project is made by : 
Aladdin Mostafa
Abdullah Ali
Raheeq Ala'a

you dont need any additional libraries or files to run it except for the folder named inc

you kindly find 2 files containing the source code 
1. parser_functions.py -> it contains all code belongs to the parser backend and drawing function

2. program.py -> it contain the gui interface code and scanner code 
it also import the first file and bound the function "program()" to the button "convert" 

link to repo: https://github.com/Aladdin95/TinyParser